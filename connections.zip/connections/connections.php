<?php

$servername="mysql.hostinger.in";
$username="u729336164_mohit";
$password="mysql.hostinger.in";
$database="u729336164_inter";




$connect=mysqli_connect($servername,$username,$password,$database);


if($connect->connect_error){
	 die('Error connecting to MySQL server.');
}

echo "connected successfully";







?>